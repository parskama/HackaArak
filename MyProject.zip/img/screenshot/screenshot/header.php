<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="style.css" type="text/css" rel="stylesheet" />
<script language="javascript" src="js/jquery 2.1.3.js"></script>
<script src="js/index.js"></script>

</head>

<body>
<div class="fixtop">
</div>
<header>
	<div class="title_h">
    	<span class="txts">سلام مدیر</span>
        <div class="img_header">
        	<div class="imgheader">
            </div>
        </div>
        <div class="ul_header">
        	<ul>
            	<li>
                	<img src="images/+.png" />
                </li>
                <li>
            	    <a href="addevent.php">افزودن رویداد ها</a>
                </li>
            </ul>
            <ul>
            	<li>
                	<img src="images/hazerin.jpg" />
                </li>
                <li>
            	    <a href="submitevent.php">حاضرین رویداد</a>
                </li>
            </ul>
            <ul>
            	<li>
                	<img src="images/ejra.png" />
                </li>
                <li>
            	    تیم اجرایی
                </li>
            </ul>
            <ul>
            	<li>
                	<img src="images/about.png" />
                </li>
                <li>
            	    <a href="about.php">درباره هاکا</a>
                </li>
            </ul>
            <ul>
            	<li>
                	<img src="images/moshakhasat.png" />
                </li>
                <li>
            	    <a href="addadmin.php">مشخصات مدیریت</a>
                </li>
            </ul>
             <ul>
            	<li>
                	<img src="images/add2.png" />
                </li>
                <li>
            	    <a href="addcity.php">اضافه کردن شهر</a>
                </li>
            </ul>
        </div>
    </div>
</header>