<?php require("header.php"); ?>
			<section class="mainContent passmgmtCls" id="changepassbox">
				<form action="#">
					<b>نام کاربری:</b><span> aref</span>
					<b>ایمیل:</b><span>aref@aref.com</span>
					<div>
						<b>پسورد فعلی:</b><input type="password" >
					</div>
					<div>
						<b>پسورد جدید</b><input type="password" >
					</div>
					<div>
						<b>تکرار پسورد</b><input type="password" >
					</div>
					<div id="submitform">
                        <div id="animate"></div>
                         <b>ثبت نام</b>
                    </div>
				</form>
			</section>
		</div>
	</div>
	<footer class="site-footer">
		<p>Copyright &copy; 2014 - All right reserved</p>	
	</footer>
</body>
</html>