<?php

require("header.php");

?>
<div class="addevent">
	<div class="header_addevent">
    	درباره هاکا
    </div>
    <div class="content_addevent">
    	<div id="box1">
        	 <div class="labeltypeevent">
                  درباره هاکا
             </div>
        	<textarea class="txtarea_addevent" id="txtareaabout">
            </textarea>
        </div>
        <div class="box2">
        	<div class="labeltypeevent">
                لینک فیسبوک
            </div>
            <input type="text" id="linkfb" class="txtaddevent" placeholder="" />
        </div>
        <div class="box2">
        	<div class="labeltypeevent">
                لینک توییتر
            </div>
            <input type="text" id="linktweet" class="txtaddevent" placeholder="" />
        </div>
        <div class="box2">
        	<input type="button" value="ذخیره" class="btnsaveevent" id="btnsaveabout" />
        </div>
        </div>
    </div>
</div>