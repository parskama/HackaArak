<?php
require("session.php");
require("header.php"); 
?>

</body>
</html>
