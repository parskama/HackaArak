<?php
session_destroy(); 
header("location : http://www.parskama.ir");
?>