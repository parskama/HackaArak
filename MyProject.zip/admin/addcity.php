<?php require("header.php"); ?>

<div class="addevent">
	<div class="header_addevent">
    	افزودن شهر جدید
    </div>
    <div class="content_addevent">
    	<div id="box1">
            <div class="labeltypeevent">
                نام شهر
            </div>
            <input type="text" style="width:373px;" class="txtaddevent" id="txtaddcity" placeholder="" />
        </div>
         <div class="box2">
        	<input type="button" value="ذخیره" id="addcity" class="btnsaveevent" />
        </div>
     </div>
</div>